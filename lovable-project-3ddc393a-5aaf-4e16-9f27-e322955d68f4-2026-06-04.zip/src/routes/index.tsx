import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";
import { Hero } from "@/components/sections/Hero";
import { Updates } from "@/components/sections/Updates";
import { About } from "@/components/sections/About";
import { Collaborations } from "@/components/sections/Collaborations";
import { Reviews } from "@/components/sections/Reviews";
import { ContactInfo } from "@/components/sections/ContactInfo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pure Drop Dairy Farms — Fresh Milk. Pure Quality." },
      { name: "description", content: "Enterprise dairy farm delivering fresh, pure milk from farm to home. Precision farming, ethical practices, premium quality." },
      { property: "og:title", content: "Pure Drop Dairy Farms — Fresh Milk. Pure Quality." },
      { property: "og:description", content: "Fresh Milk Direct From Farm To Home." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <SiteShell>
      <Hero />
      <Collaborations />
      <Updates />
      <About />
      <Reviews />
      <ContactInfo />
    </SiteShell>
  );
}
