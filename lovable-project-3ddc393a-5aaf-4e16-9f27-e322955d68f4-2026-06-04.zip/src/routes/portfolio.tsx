import { createFileRoute } from "@tanstack/react-router";
import { motion } from "motion/react";
import { Award, PlayCircle, Building2 } from "lucide-react";
import { SiteShell } from "@/components/SiteShell";
import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";
import g4 from "@/assets/gallery-4.jpg";
import u1 from "@/assets/update-1.jpg";
import u2 from "@/assets/update-2.jpg";
import u3 from "@/assets/update-3.jpg";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Portfolio — Pure Drop Dairy Farms" },
      { name: "description", content: "Gallery, films, collaborations, achievements and certifications from Pure Drop Dairy Farms." },
      { property: "og:title", content: "Portfolio — Pure Drop Dairy Farms" },
      { property: "og:description", content: "A visual journey through our farm, partners, and certifications." },
    ],
  }),
  component: PortfolioPage,
});

const gallery = [g1, g2, g3, g4, u1, u2, u3, g1];
const collaborations = ["Grand Hyatt", "Whole Foods", "Blue Bottle", "Ritz Carlton", "Compass Group", "Four Seasons", "Marriott", "Hilton Hotels"];
const achievements = [
  { year: "2025", title: "Best Sustainable Dairy — National Agri Awards" },
  { year: "2024", title: "Carbon Neutral Certification renewed" },
  { year: "2023", title: "500,000 home deliveries milestone" },
  { year: "2022", title: "Enterprise Quality Excellence Award" },
];
const certificates = ["ISO 22000:2018", "FSSAI Certified", "USDA Organic", "Rainforest Alliance", "B-Corp Certified"];

function PortfolioPage() {
  return (
    <SiteShell>
      <section className="pt-32 pb-16">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="text-[10px] font-bold uppercase tracking-widest text-yellow">Portfolio</span>
            <h1 className="mt-4 max-w-[18ch] text-balance font-serif text-5xl leading-[0.95] text-navy md:text-7xl">
              A visual <span className="italic">archive</span> of our work.
            </h1>
            <p className="mt-6 max-w-[55ch] text-pretty text-lg text-muted-foreground">
              From sunrise milking to enterprise partnerships — the moments, milestones and credentials that define Pure Drop.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="Gallery" title="Moments from the farm" />
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
            {gallery.map((src, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: (i % 4) * 0.05 }}
                className={`overflow-hidden rounded-lg ${i % 5 === 0 ? "md:row-span-2 md:aspect-[1/2]" : "aspect-square"}`}
              >
                <img src={src} alt={`Gallery ${i + 1}`} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 hover:scale-105" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Videos */}
      <section className="bg-navy py-24 text-cream">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="Films" title="Watch the farm in motion" dark />
          <div className="grid gap-6 md:grid-cols-3">
            {[g1, g3, g4].map((src, i) => (
              <div key={i} className="group relative aspect-video overflow-hidden rounded-xl">
                <img src={src} alt="Video" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-70 transition-opacity group-hover:opacity-90" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <PlayCircle className="size-14 text-yellow drop-shadow-lg transition-transform group-hover:scale-110" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Collaborations */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="Collaborations" title="Partners we serve" />
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-xl bg-navy/10 sm:grid-cols-3 lg:grid-cols-4">
            {collaborations.map((c) => (
              <div key={c} className="flex h-32 items-center justify-center bg-cream px-4">
                <div className="flex flex-col items-center gap-2 text-center">
                  <Building2 className="size-5 text-yellow" />
                  <span className="font-serif text-lg text-navy">{c}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="bg-muted/40 py-24">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="Achievements" title="Milestones along the way" />
          <ol className="relative border-l-2 border-yellow/30 pl-8">
            {achievements.map((a, i) => (
              <motion.li
                key={a.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="relative mb-10 last:mb-0"
              >
                <span className="absolute -left-[42px] flex size-5 items-center justify-center rounded-full border-2 border-yellow bg-cream" />
                <span className="font-mono text-xs font-bold text-yellow">{a.year}</span>
                <h4 className="mt-1 font-serif text-2xl text-navy">{a.title}</h4>
              </motion.li>
            ))}
          </ol>
        </div>
      </section>

      {/* Certificates */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="Certifications" title="Verified by global standards" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {certificates.map((c) => (
              <div key={c} className="flex items-center gap-4 rounded-xl border border-navy/10 bg-white p-6 transition-shadow hover:shadow-elevated">
                <Award className="size-8 shrink-0 text-yellow" />
                <div>
                  <h4 className="font-serif text-lg text-navy">{c}</h4>
                  <p className="text-xs text-muted-foreground">Active certification</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </SiteShell>
  );
}

function SectionTitle({ eyebrow, title, dark }: { eyebrow: string; title: string; dark?: boolean }) {
  return (
    <div className="mb-12">
      <span className={`text-[10px] font-bold uppercase tracking-widest ${dark ? "text-yellow" : "text-yellow"}`}>{eyebrow}</span>
      <h2 className={`mt-4 font-serif text-4xl font-medium md:text-5xl ${dark ? "text-cream" : "text-navy"}`}>{title}</h2>
    </div>
  );
}
