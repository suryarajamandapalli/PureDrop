import { useEffect, useState, type ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { Preloader } from "./Preloader";
import { WelcomePopup } from "./WelcomePopup";

export function SiteShell({ children }: { children: ReactNode }) {
  const [loaded, setLoaded] = useState(false);
  const [welcomeOpen, setWelcomeOpen] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const seen = sessionStorage.getItem("pd_preloaded");
    if (seen) {
      setLoaded(true);
    }
  }, []);

  const handlePreloadDone = () => {
    sessionStorage.setItem("pd_preloaded", "1");
    setLoaded(true);
    // Show welcome popup only the very first session visit
    const popupSeen = sessionStorage.getItem("pd_welcomed");
    if (!popupSeen) {
      setTimeout(() => setWelcomeOpen(true), 400);
      sessionStorage.setItem("pd_welcomed", "1");
    }
  };

  return (
    <>
      {!loaded && <Preloader onComplete={handlePreloadDone} />}
      <WelcomePopup open={welcomeOpen} onClose={() => setWelcomeOpen(false)} />
      <Navbar />
      <main className="min-h-screen">{children}</main>
      <Footer />
    </>
  );
}
