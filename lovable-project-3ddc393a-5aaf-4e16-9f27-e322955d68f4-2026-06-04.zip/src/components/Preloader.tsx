import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface PreloaderProps {
  onComplete: () => void;
}

export function Preloader({ onComplete }: PreloaderProps) {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let raf: number;
    const start = performance.now();
    const duration = 2200;
    const tick = (t: number) => {
      const p = Math.min(100, ((t - start) / duration) * 100);
      setProgress(p);
      if (p < 100) raf = requestAnimationFrame(tick);
      else {
        setDone(true);
        setTimeout(onComplete, 600);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-navy"
          exit={{ opacity: 0, y: "-100%" }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          {/* Milk drop */}
          <div className="relative h-40 w-40">
            <motion.div
              className="absolute left-1/2 top-0 -translate-x-1/2"
              initial={{ y: -40, opacity: 0 }}
              animate={{ y: 90, opacity: 1 }}
              transition={{ duration: 0.9, ease: [0.6, 0, 0.8, 0.2] }}
            >
              <div className="size-6 rounded-full bg-cream shadow-[0_0_30px_rgba(255,212,71,0.5)]"
                   style={{ borderRadius: "50% 50% 50% 50% / 60% 60% 40% 40%" }} />
            </motion.div>
            {/* Splash ring */}
            <motion.div
              className="absolute left-1/2 top-[110px] -translate-x-1/2 rounded-full border-2 border-yellow"
              initial={{ width: 0, height: 0, opacity: 0 }}
              animate={{ width: 140, height: 30, opacity: [0, 1, 0] }}
              transition={{ duration: 0.6, delay: 0.85, ease: "easeOut" }}
              style={{ marginLeft: -70, marginTop: -15 }}
            />
            {/* Splash droplets */}
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute left-1/2 top-[110px] size-2 rounded-full bg-cream"
                initial={{ x: 0, y: 0, opacity: 0 }}
                animate={{
                  x: Math.cos((i / 6) * Math.PI * 2) * 60,
                  y: Math.sin((i / 6) * Math.PI * 2) * 20 - 10,
                  opacity: [0, 1, 0],
                }}
                transition={{ duration: 0.7, delay: 0.9 }}
              />
            ))}
          </div>

          {/* Logo reveal */}
          <motion.div
            className="mt-12 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 1.2 }}
          >
            <h1 className="font-serif text-4xl text-cream tracking-tight">
              Pure Drop <span className="text-yellow">Dairy Farms</span>
            </h1>
            <p className="mt-2 text-[10px] font-semibold uppercase tracking-[0.3em] text-cream/50">
              Fresh Milk · Pure Quality
            </p>
          </motion.div>

          {/* Progress */}
          <motion.div
            className="mt-12 w-64"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3 }}
          >
            <div className="h-px w-full overflow-hidden bg-cream/10">
              <motion.div
                className="h-full bg-yellow"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="mt-3 text-center font-mono text-[10px] tracking-widest text-cream/60">
              {Math.round(progress).toString().padStart(3, "0")}%
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
